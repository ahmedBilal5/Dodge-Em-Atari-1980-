#include <iostream>
#include <string>
using namespace std;
int i=5;
string s;
void strconverter(){
	s=to_string(i);
}
int main(){
	strconverter();
    	if(s=="5")
        cout<<"converted to string";
    	else
        cout<<"Failed to convert.";
	return 0;
}

